// لوحة الإدارة — للأدمن فقط
import { useEffect, useState } from "react";
import { api } from "../lib/api.js";
import { Users, Activity, DollarSign } from "lucide-react";

export default function Admin() {
  const [stats, setStats] = useState(null);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        // المسار يُؤكَّد مع الباك-إند (admin router)
        const data = await api.get("/api/admin/stats");
        setStats(data);
      } catch (e) {
        setErr(e.message);
      }
    })();
  }, []);

  return (
    <>
      {err && <div className="alert info">تعذّر جلب بيانات الإدارة: {err} — (نؤكّد مسار admin مع الباك-إند)</div>}

      <div className="grid grid-3" style={{ marginBottom: 24 }}>
        <div className="card stat">
          <span className="label"><Users size={14} style={{ verticalAlign: "middle", marginLeft: 6 }} /> المستخدمون</span>
          <span className="value">{stats?.total_users ?? "—"}</span>
        </div>
        <div className="card stat">
          <span className="label"><DollarSign size={14} style={{ verticalAlign: "middle", marginLeft: 6 }} /> مشتركو PRO</span>
          <span className="value">{stats?.pro_users ?? "—"}</span>
        </div>
        <div className="card stat">
          <span className="label"><Activity size={14} style={{ verticalAlign: "middle", marginLeft: 6 }} /> صفقات اليوم</span>
          <span className="value">{stats?.trades_today ?? "—"}</span>
        </div>
      </div>

      <div className="card">
        <div className="card-title">إدارة المستخدمين</div>
        <div className="empty">قائمة المستخدمين والتحكّم — تُوصل بمسار admin</div>
      </div>
    </>
  );
}
