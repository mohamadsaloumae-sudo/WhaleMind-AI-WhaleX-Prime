// الإعدادات — الحساب
import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { User, Shield, LogOut } from "lucide-react";

export default function Settings() {
  const { user, logout } = useAuth();

  return (
    <div style={{ maxWidth: 560 }}>
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-title"><User size={14} style={{ verticalAlign: "middle", marginLeft: 6 }} /> الحساب</div>
        <div style={{ display: "grid", gap: 12, fontSize: 14 }}>
          <div className="toggle-row" style={{ margin: 0 }}>
            <span style={{ color: "var(--txt-2)" }}>المعرّف</span>
            <span style={{ fontFamily: "monospace" }}>{user?.uid}</span>
          </div>
          <div className="toggle-row" style={{ margin: 0 }}>
            <span style={{ color: "var(--txt-2)" }}>الباقة</span>
            <span className="badge grade">{user?.tier}</span>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title"><Shield size={14} style={{ verticalAlign: "middle", marginLeft: 6 }} /> الأمان</div>
        <p style={{ fontSize: 13.5, color: "var(--txt-2)", marginBottom: 16 }}>
          مفاتيح Binance مشفّرة بالكامل. يمكنك قطع الربط أي وقت من صفحة التداول.
        </p>
        <button className="btn btn-danger" onClick={logout}>
          <LogOut size={16} /> تسجيل الخروج
        </button>
      </div>
    </div>
  );
}
