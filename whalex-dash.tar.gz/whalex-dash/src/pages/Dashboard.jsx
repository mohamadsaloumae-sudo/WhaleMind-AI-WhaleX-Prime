// الرئيسية — نظرة عامة
import { useEffect, useState } from "react";
import { Activity, TrendingUp, Bot, Radio } from "lucide-react";

export default function Dashboard() {
  const [live, setLive] = useState(false);

  // ربط WebSocket للبثّ الحيّ (الأسعار/الإشارات)
  useEffect(() => {
    let ws;
    try {
      const proto = location.protocol === "https:" ? "wss" : "ws";
      ws = new WebSocket(`${proto}://${location.host}/ws`);
      ws.onopen = () => setLive(true);
      ws.onclose = () => setLive(false);
    } catch { /* تجاهل */ }
    return () => ws && ws.close();
  }, []);

  return (
    <>
      <div className="grid grid-4" style={{ marginBottom: 24 }}>
        <div className="card stat">
          <span className="label">الحالة</span>
          <span className="value green" style={{ fontSize: 20 }}>
            {live ? "متّصل حيّ" : "غير متّصل"}
          </span>
        </div>
        <div className="card stat">
          <span className="label">الصفقات المفتوحة</span>
          <span className="value">—</span>
        </div>
        <div className="card stat">
          <span className="label">ربح اليوم</span>
          <span className="value green">—</span>
        </div>
        <div className="card stat">
          <span className="label">نسبة الفوز</span>
          <span className="value">—</span>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="card-title"><Radio size={14} style={{ verticalAlign: "middle", marginLeft: 6 }} /> حالة الرادارات</div>
          <div className="toggle-row">
            <span>Peak Hunter — SHORT/LONG</span>
            <span className="badge grade">يعمل</span>
          </div>
          <div className="toggle-row">
            <span>Predator — اتّجاهي</span>
            <span className="badge grade">يعمل</span>
          </div>
        </div>
        <div className="card">
          <div className="card-title"><Activity size={14} style={{ verticalAlign: "middle", marginLeft: 6 }} /> آخر النشاط</div>
          <div className="empty">سيظهر النشاط الحيّ هنا عبر WebSocket</div>
        </div>
      </div>
    </>
  );
}
