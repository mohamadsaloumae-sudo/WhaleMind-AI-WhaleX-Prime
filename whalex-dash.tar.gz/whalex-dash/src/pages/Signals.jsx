// الإشارات الحيّة — بطاقات
import { useEffect, useState } from "react";
import { api } from "../lib/api.js";

export default function Signals() {
  const [signals, setSignals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  async function load() {
    try {
      // المسار الفعلي يُؤكَّد مع الباك-إند (signals router)
      const data = await api.get("/api/signals/recent");
      setSignals(Array.isArray(data) ? data : data?.signals || []);
    } catch (e) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const t = setInterval(load, 15000); // تحديث كل 15ث
    return () => clearInterval(t);
  }, []);

  if (loading) return <div className="loading">جارٍ تحميل الإشارات…</div>;

  return (
    <>
      {err && <div className="alert info">تعذّر جلب الإشارات: {err} — (نؤكّد المسار مع الباك-إند)</div>}
      {signals.length === 0 ? (
        <div className="card"><div className="empty">لا إشارات حالياً</div></div>
      ) : (
        <div className="grid grid-3">
          {signals.map((s, i) => (
            <div className="card" key={i}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                <strong>{s.symbol}</strong>
                <span className={`badge ${s.direction === "LONG" ? "long" : "short"}`}>
                  {s.direction}
                </span>
              </div>
              <div style={{ fontSize: 13, color: "var(--txt-2)", display: "grid", gap: 6 }}>
                <div>الدخول: <b style={{ color: "var(--txt-1)" }}>{s.entry}</b></div>
                <div>الوقف: {s.sl}</div>
                <div>الهدف: {s.tp1}</div>
                <div>التصنيف: <span className="badge grade">{s.grade}</span> · ثقة {s.confidence}%</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
