// صفقاتي — المفتوحة والمغلقة
import { useEffect, useState } from "react";
import { binance } from "../lib/api.js";

export default function Trades() {
  const [positions, setPositions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  async function load() {
    try {
      const data = await binance.positions();
      setPositions(Array.isArray(data) ? data : data?.positions || []);
    } catch (e) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const t = setInterval(load, 10000);
    return () => clearInterval(t);
  }, []);

  if (loading) return <div className="loading">جارٍ تحميل الصفقات…</div>;

  return (
    <>
      {err && <div className="alert info">تعذّر جلب الصفقات: {err} — (يتطلّب ربط Binance)</div>}
      <div className="card">
        <div className="card-title">الصفقات المفتوحة</div>
        {positions.length === 0 ? (
          <div className="empty">لا صفقات مفتوحة حالياً</div>
        ) : (
          <table className="tbl">
            <thead>
              <tr>
                <th>العملة</th><th>الاتّجاه</th><th>الدخول</th>
                <th>الحالي</th><th>الرافعة</th><th>الربح/الخسارة</th>
              </tr>
            </thead>
            <tbody>
              {positions.map((p, i) => (
                <tr key={i}>
                  <td><b>{p.symbol}</b></td>
                  <td><span className={`badge ${p.direction === "LONG" || p.positionAmt > 0 ? "long" : "short"}`}>
                    {p.direction || (p.positionAmt > 0 ? "LONG" : "SHORT")}
                  </span></td>
                  <td>{p.entry_price || p.entryPrice}</td>
                  <td>{p.mark_price || p.markPrice || "—"}</td>
                  <td>{p.leverage}x</td>
                  <td style={{ color: (p.pnl || p.unRealizedProfit) >= 0 ? "var(--green)" : "var(--red)", fontWeight: 700 }}>
                    {Number(p.pnl || p.unRealizedProfit || 0).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
