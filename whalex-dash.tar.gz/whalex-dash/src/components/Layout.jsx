// الإطار العام للصفحات الداخلية
import Sidebar from "./Sidebar.jsx";

export default function Layout({ title, children }) {
  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-area">
        <header className="topbar">
          <h1>{title}</h1>
          <div className="spacer" />
          <span className="status-dot">النظام يعمل</span>
        </header>
        <div className="page-body">{children}</div>
      </div>
    </div>
  );
}
